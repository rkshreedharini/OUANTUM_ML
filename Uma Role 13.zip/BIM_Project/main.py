import json
import cadquery as cq

# Read JSON
with open("input.json") as file:
    data = json.load(file)

building = None

# Create walls
for wall in data["walls"]:

    x1, y1 = wall["start"]
    x2, y2 = wall["end"]

    thickness = wall["thickness"]*1000
    height = wall["height"]*1000

    if y1 == y2:
        length = abs(x2 - x1)*1000

        solid = (
            cq.Workplane("XY")
            .box(length, thickness, height)
            .translate(((x1 + x2) / 2*1000, y1*1000, height / 2))
        )

    else:
        length = abs(y2 - y1)*1000

        solid = (
            cq.Workplane("XY")
            .box(thickness, length, height)
            .translate((x1*1000, (y1 + y2) / 2*1000, height / 2))
        )

    if building is None:
        building = solid
    else:
        building = building.union(solid)

# -----------------------
# Door
# -----------------------

door = (
    cq.Workplane("XY")
    .box(1.0*1000, 0.25*1000, 2.1*1000)
    .translate((3*1000, 0, 1.05*1000))
)

building = building.cut(door)

# -----------------------
# Window 1
# -----------------------

window1 = (
    cq.Workplane("XY")
    .box(1.2*1000, 0.25*1000, 1.2*1000)
    .translate((2*1000, 4*1000, 1.8*1000))
)

building = building.cut(window1)

# -----------------------
# Window 2
# -----------------------

window2 = (
    cq.Workplane("XY")
    .box(1.2*1000, 0.25*1000, 1.2*1000)
    .translate((4.5*1000, 4*1000, 1.8*1000))
)

building = building.cut(window2)

# Export
cq.exporters.export(building, "output/building.step")

print("Building with Door Created Successfully!")