# Perception Assignment

Three perception modules for a BIM (Building Information Modeling) vision pipeline,
covering symbol detection, text extraction, and raster-to-vector conversion of
architectural floor plans.

## Contents

| Directory | Module | Description |
|---|---|---|
| [`bim-vision-role7-symbol-detection-main/`](bim-vision-role7-symbol-detection-main/) | Role 7 — Symbol detection | Detection pipeline with dataset adapters (COCO, YOLO, VOC, CubiCasa, Label Studio), calibration, thresholding, and evaluation. See its [README](bim-vision-role7-symbol-detection-main/README.md) and [CONTRACT](bim-vision-role7-symbol-detection-main/docs/CONTRACT.md). |
| [`OCR/`](OCR/) | OCR + scale detection | Multi-angle EasyOCR extraction with CLAHE preprocessing, deterministic room/dimension/scale parsing, DXF geometry merge, structured JSON export. See its [README](OCR/README.md). |
| [`role_9/`](role_9/) | Role 9 — Raster to vector | Classical and learned raster-to-vector backends behind a shared interface. |

Each module has its own dependencies; install from the `requirements.txt` inside
the relevant directory.
